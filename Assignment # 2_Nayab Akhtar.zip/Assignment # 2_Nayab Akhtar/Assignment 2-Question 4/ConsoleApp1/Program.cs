﻿using CosmicLearn;
using System;
namespace CosmicLearn
{
    public class Animal
    {
        public void Sleep()
        {
            Console.WriteLine("Zzzzzz");
        }

        public virtual void MakeNoise()
        {
            Console.WriteLine("DurrrDurrr");
        }
    }

    class Dog : Animal
    {
        public override void MakeNoise()
        {
            Console.WriteLine("WoofWoof");
        }
    }

    class Cat : Animal
    {
        public override void MakeNoise()
        {
            Console.WriteLine("Meaaooooow");
        }
    }
}
class Program
{
    static void Main(string[] args)
    {
        Animal myAnimal = new Animal();  // Create a Animal object
        Animal myDog = new Dog();  // Create a Dog object

        myAnimal.MakeNoise();
        myDog.MakeNoise();
    }
}