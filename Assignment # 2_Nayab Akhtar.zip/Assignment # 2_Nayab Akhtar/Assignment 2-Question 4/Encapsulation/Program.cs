﻿using CosmicLearn;
using System;
namespace CosmicLearn
{
    class Employee
    {
        private int employeeId;
        private string employeeName;

        //Parameterized constructor.
        public Employee(int id, string name)
        {
            this.employeeId = id;
            this.employeeName = name;
        }

        public void printDetails()
        {
            Console.WriteLine(this.employeeId);
            Console.WriteLine(this.employeeName);
        }
    }
}
class Program
{
    static void Main(string[] args)
    {
            Employee employee1 = new Employee(1, "Mugambo");
            employee1.printDetails();
        
    }
}