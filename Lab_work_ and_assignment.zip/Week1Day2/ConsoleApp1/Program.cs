﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
class Solution
{

    static void Main(String[] args)
    {
        Console.WriteLine("Enter number of queries: ");
        int q = Convert.ToInt32(Console.ReadLine());
        string hack = "hackerrank";

        for (int a0 = 0; a0 < q; a0++)
        {
            Console.WriteLine("Enter a string: ");
            string s = Console.ReadLine();
            int length = s.Length;
            int h = 0;
            for (int i = 0; i < length; i++)
            {
                if (s[i] == hack[h])
                {
                    h++;
                }
                if (h == 10)
                    break;
            }
            Console.WriteLine("Hacker rank in a string? ");
            Console.WriteLine(h == 10 ? "YES" : "NO");
        }
    }
}