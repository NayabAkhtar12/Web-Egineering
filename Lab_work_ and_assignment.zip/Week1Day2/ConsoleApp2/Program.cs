﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    internal class Program
    {
        //Parent class
        class Sports
        {
            public virtual String getName()
            {
                return "Generic Sports";
            }
           public virtual void getNumberOfTeamMembers()
            {
                Console.WriteLine("Each team has n players in " + getName());
            }
        }
        //Child class
        class Soccer : Sports
        {
            public override String getName(){
        return "Soccer Class";
    }
             public override void getNumberOfTeamMembers()
            {
                Console.WriteLine("Each team has n players in " + getName());
            }
        }
static void Main(string[] args)
        {
            Sports sp = new Sports();
            Soccer sc = new Soccer();
            //For Generic
            Console.WriteLine("Sports: ");
            Console.WriteLine(sp.getName());
            sp.getNumberOfTeamMembers();
            //For Soccer
            Console.WriteLine("Soccer: ");
            Console.WriteLine(sc.getName());
            sc.getNumberOfTeamMembers();
        }
    }
}
