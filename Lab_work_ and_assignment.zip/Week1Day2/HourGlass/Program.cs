﻿    internal class Program
    {
        //function
        static int Hourglass(int[][] arr, int x, int y)
        {
            // 00 01 02
            //    11
            // 20 21 22
            return arr[x][y] + arr[x][y + 1] + arr[x][y + 2] +
                arr[x + 1][y + 1] + arr[x + 2][y] + arr[x + 2][y + 1] + arr[x + 2][y + 2];
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Enter an array for Hourglass: ");
            int[][] arr = new int[6][];
            for (int arr_i = 0; arr_i < 6; arr_i++)
            {
                string[] arr_temp = Console.ReadLine().Split(' ');
                arr[arr_i] = Array.ConvertAll(arr_temp, Int32.Parse);
            }
            int maxsum = int.MinValue; //MIN VAL=2147483648
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    int sumHG = Hourglass(arr, i, j);
                    if (sumHG > maxsum)
                    {
                        maxsum = sumHG;
                    }
                }
            }
            Console.WriteLine("Maximum sum is : {0}", maxsum);
        }
    }