﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
class Solution
{

    static int minimumNumber(int n, string password)
    {
        // Return the minimum number of characters to make the password strong
        string
            numbers = "[0123456789]",
            lower_case = "[abcdefghijklmnopqrstuvwxyz]",
            upper_case = "[ABCDEFGHIJKLMNOPQRSTUVWXYZ]",
            special_characters = @"[!@#$%^&*()\-+]";

        int charsToAdd = 0;

        if (!Regex.IsMatch(password, numbers)) charsToAdd++;
        if (!Regex.IsMatch(password, lower_case)) charsToAdd++;
        if (!Regex.IsMatch(password, upper_case)) charsToAdd++;
        if (!Regex.IsMatch(password, special_characters)) charsToAdd++;

        if (n + charsToAdd < 6) charsToAdd = 6 - n;

        return charsToAdd;
    }

    static void Main(String[] args)
    {
        Console.WriteLine("Enter the length of the Password: ");
        int n = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter a Password: ");
        string password = Console.ReadLine();
        int answer = minimumNumber(n, password);
        Console.WriteLine("Output: ");
        Console.WriteLine(answer);
    }
}