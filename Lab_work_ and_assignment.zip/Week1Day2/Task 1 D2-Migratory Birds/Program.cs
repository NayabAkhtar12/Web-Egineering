﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
class Solution
{

    static void Main(String[] args)
    {
        Console.WriteLine("Enter size of the Array");
        int n = Convert.ToInt32(Console.ReadLine());
        string[] types_temp = Console.ReadLine().Split(' ');
        int[] types = Array.ConvertAll(types_temp, Int32.Parse);

        Dictionary<int, int> birds = new Dictionary<int, int>();

        foreach (int i in types)
        {
            if (!birds.ContainsKey(i))
            {
                birds.Add(i, 1);
            }
            else
            {
                birds[i]++;
            }
        }

        int min = birds.OrderBy(kvp => kvp.Value).Last().Key;
        Console.WriteLine("The type number that occurs at the highest frequency is  ");
        Console.WriteLine(min);
    }
}