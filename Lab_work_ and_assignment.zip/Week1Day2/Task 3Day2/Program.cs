﻿using System;
using System.Collections.Generic;
using System.IO;
class Solution
{
    static void Main(String[] args)
    {
        Console.WriteLine("Enter size of Array: ");
        int N = Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter an Array");
        string[] str = Console.ReadLine().Split();
        int count = 0;
        for (int i = 0; i < N; i++)
        {
            count = count + Convert.ToInt32(str[i]);
        }
        Console.WriteLine("Simple Array Sum: ");
        Console.Write(count);
    }
}