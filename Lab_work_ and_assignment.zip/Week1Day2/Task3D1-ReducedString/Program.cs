﻿using System;
using System.Collections.Generic;
using System.IO;
class Solution
{
    static void Main(String[] args)
    {
        Console.WriteLine("Enter a string: ");
        string str = Console.ReadLine();
        bool check = true;
        while (check && str.Length > 1)
        {
            check = false;
            for (int i = 0; i < str.Length - 1; i++)
                if (str[i] == str[i + 1])
                {
                    str = str.Remove(i, 2);
                    check = true;
                    break;
                }
        }
        Console.WriteLine("Reduced string: ");
        Console.WriteLine(str.Length > 0 ? str : "Empty String");
    }
}