﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

class Solution
{
    static void Main(String[] args)
    {
        Console.WriteLine("Enter the number of rows and columns in the square matrix: ");
        int N = int.Parse(Console.ReadLine());
        var array = new List<int[]>(N);
        Console.WriteLine("Enter Matrix: ");
        for (int i = 0; i < N; i++)
        {
            array.Add(Console.ReadLine().Split(' ').Select(int.Parse).ToArray());
        }

        var matrix = array.ToArray();

        int diag1 = 0;
        int diag2 = 0;
        for (int i = 0, j = N - 1; i < N; i++, j--)
        {
            diag1 += matrix[i][i];
            diag2 += matrix[i][j];
        }
        Console.WriteLine("Diagonal Difference: ");
        Console.WriteLine(Math.Abs(diag1 - diag2));
    }
}