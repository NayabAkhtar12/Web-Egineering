﻿using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.Collections;
using System.ComponentModel;
using System.Diagnostics.CodeAnalysis;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text.RegularExpressions;
using System.Text;
using System;

class Result
{

    /*
     * Complete the 'plusMinus' function below.
     *
     * The function accepts INTEGER_ARRAY arr as parameter.
     */

    public static void plusMinus(List<int> arr)
    {
        float pos = 0;
        float neg = 0;
        float zero = 0;
        foreach (int item in arr)
        {
            if (item > 0)
            {
                pos++;
            }
            else if (item == 0)
            {
                zero++;
            }
            else
            {
                neg++;
            }
        }
        pos = pos / arr.Count();
        Console.WriteLine(pos);
        neg = neg / arr.Count();
        Console.WriteLine(neg);
        zero = zero / arr.Count();
        Console.WriteLine(zero);
    }

}

class Solution
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter size of Array: ");
        int n = Convert.ToInt32(Console.ReadLine().Trim());
        Console.WriteLine("Enter an Array: ");
        List<int> arr = Console.ReadLine().TrimEnd().Split(' ').ToList().Select(arrTemp => Convert.ToInt32(arrTemp)).ToList();
        Console.WriteLine("PlusMinus: ");
        Result.plusMinus(arr);
    }
}