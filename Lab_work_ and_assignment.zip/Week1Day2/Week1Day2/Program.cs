﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
class Solution
{

    static void Main(String[] args)
    {
        Console.WriteLine("Original Message: ");
        string s = Console.ReadLine();
        var count = 0;
        for (var i = 0; i <= s.Length - 3; i += 3)
        {
            if (s[i] != 'S') count++;
            if (s[i + 1] != 'O') count++;
            if (s[i + 2] != 'S') count++;
        }
        Console.WriteLine("Output Message: ");
        Console.WriteLine(count);
    }
}