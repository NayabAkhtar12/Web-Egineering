﻿// Abstract class
abstract class Book
{
   public String title;
   public  abstract void setTitle(String s);
    public String getTitle()
    {
        return title;
    }
}

// Derived class (inherited from Book)
 class Book1:Book
{
    public override void setTitle(string s)
    {
        title = s;
    }
}

class Program
{
    static void Main(string[] args)
    {
        Book1 n1 = new Book1();
        string title = "A tale of two cities";
        n1.setTitle(title); 
        Console.WriteLine("Title of the Book is:  {0}", n1.getTitle());
    }
}