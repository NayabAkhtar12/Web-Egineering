﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week1Day3_Lab_3_2_Task_Inheritance_II
{
    internal class Adder : Arithmatic
    {

    }
}
