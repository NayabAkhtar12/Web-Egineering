﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Week1Day3_Lab_3_2_Task_Inheritance_II
{ 
internal class Program
{
        static void Main(string[] args)
        {

        //  int A2 = A1.(1, 2);
        Adder A1 = new Adder();
            Console.WriteLine("My superclass is: " + typeof(Adder).BaseType.Name);
            Console.WriteLine(A1.Add(5,3) + " " + A1.Add(5, 5) + " " + A1.Add(10, 20));
        }
}
}