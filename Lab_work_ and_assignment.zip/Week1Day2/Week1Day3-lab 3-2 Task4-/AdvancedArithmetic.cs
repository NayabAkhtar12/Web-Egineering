﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week1Day3_lab_3_2_Task4_
{
    public interface AdvancedArithmetic
    {
        int divisor_sum(int n) 
        { return n; }
    }
}
