﻿using System;

namespace Week1Day3_lab_3_2_Task4_
{
     public class MyCalculator : AdvancedArithmetic
    {
        public int divisor_sum(int x)
        {
            int sum = 0;
            for (int i = 1; i <= x; i++)
            {
                if (x % i == 0) 
                    sum += i;
            }
            return sum;
        }
    }
    internal class Program
    {
        static void Main()
        {
            MyCalculator m1 = new MyCalculator();
            Console.WriteLine("I implemented: " + typeof(AdvancedArithmetic).Name);

            int n = 2;
            Console.WriteLine("Sum of divisors of " + n + " is " + m1.divisor_sum(n) + ".\n");
        }
    }
}
