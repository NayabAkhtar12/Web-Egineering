﻿using System;
namespace y
{
    internal class Task4
    {
       
        static void printStrongNess(String input)
        {
            int n = input.Length;

            // Checking lower alphabet in string
          
            // Strength of password
            Console.WriteLine("Strength of password:-");
            if (hasLower && hasUpper && hasDigit &&
                specialChar && (n >= 8))
                Console.WriteLine("Strong: All characters in  are in the password [a-z], [A-Z], [0-9], or [!@#$%^&*()-+ ].");
            else if ((hasLower || hasUpper) &&
                     specialChar && (n >= 6))
                Console.WriteLine("Moderate");
            else
                Console.WriteLine("weak");
        }
        public static void Main(String[] args)
        {
            string input = "GeeksforGeeks!@12";
            printStrongNess(input);
        }
    }
}
