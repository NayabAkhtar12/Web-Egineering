﻿// C# program for the above approach
using System;

public class Task2
{
    static bool isupper(char st)
    {
        if (st >= 'A' && st <= 'Z')
            return true;
        else
            return false;
    }

    // Function to count the number of
    // camelcase characters
    static void countCamelCase(String s)
    {

        // Stores the count of all the
        // camelcase characters
        int count = 0;

        // Traverse the String S
        for (int i = 0; i < s.Length; i++)
        {

            // Check if the character is
            // an uppercase letter or
            // not using isupper()
            char st = s[i];
            if (isupper(st))
            {

                // Increment the count
                count++;
            }
        }

        // Print the total count
        Console.Write(count);
    }

    // Driver Code
    public static void Main(String[] args)
    {
        String str = "myNameIsNayab";
        countCamelCase(str);
    }
}

