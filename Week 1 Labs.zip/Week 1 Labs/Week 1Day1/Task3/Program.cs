﻿//main class
namespace y
{ 
internal class Task3
{

        //methods
        public static void Reducedstring(string s)
        {
            int count = 1;
            for (int i = 1; i < s.Length; i++)
            {
                if (s[i] = s[i] - 1)
                {
                    count = count / 2;
                }
                else if (s == null)
                    Console.WriteLine("Empty Strings");
                else
                    Console.WriteLine("exit");
            }
        }
    //main
    public static void Main(String[] args)
    {
        string s = "naayab";
        Reducedstring(s);
    }
}
}