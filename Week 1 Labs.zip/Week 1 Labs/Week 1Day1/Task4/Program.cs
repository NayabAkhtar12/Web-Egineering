﻿namespace y
{
    internal class Task4
    {
        public static void password(String s)
        {
          // char ch = Convert.ToChar(Console.ReadLine());
            for (int i = 0; i < s.Length; i++)
            {
                char ch = s[i];
                if (s.Length < 6)
                    Console.WriteLine("Length of the password must be at least 6 characters");
                if (s is null)
                    Console.WriteLine("Your  password must have at least 1 digit, it can't be null");
                if (ch>='a' && ch<='a')
                    Console.WriteLine("Your  password must have at least 1 lower case letter");
                if ((ch>='A' && ch<='A'))
                    Console.WriteLine("Your  password must have at least 1 uppers case letter");              
                else 
                    Console.WriteLine("Password is strong");
            }
        }
        public static void Main(String[] args)
        {
            string s = "nayab";
            password(s);
        }
    }
}