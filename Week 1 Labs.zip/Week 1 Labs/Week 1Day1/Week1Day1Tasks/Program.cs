﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week1Day1Tasks
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string var = "Hello world";
            Console.WriteLine(var);
                }
    }
}
