﻿using System;
namespace y
{
    internal class Task4
    {
        static bool isupper(char st)
        {
            if (st >= 'A' && st <= 'Z')
                return true;
            else
                return false;
        }
        static bool islower(char st)
        {
            if (st >= 'a' && st <= 'z')
                return true;
            else
                return false;
        }
        static void printStrongNess(String input)
        {
            int n = input.Length;

            // Checking lower alphabet in string
            bool hasLower = false, hasUpper = false;
            bool hasDigit = false, specialChar = false;
           // string normalChars = "abcdefghijklmnopqrstu";

            for (int i = 0; i < n; i++)
            {
                if (isupper(input[i]))
                    hasLower = true;
                if (islower(input[i]))
                    hasUpper = true;
              //  if (hasDigit(input[i])) 
                   // hasDigit = true;
            }

            // Strength of password
            Console.WriteLine ("Strength of password:-") ;
            if (hasLower && hasUpper && hasDigit &&
                specialChar && (n >= 8))
                Console.WriteLine("Strong: All characters in  are in the password [a-z], [A-Z], [0-9], or [!@#$%^&*()-+ ].");
            else if ((hasLower || hasUpper) &&
                     specialChar && (n >= 6))
                Console.WriteLine("Moderate");
            else
                Console.WriteLine("weak");
        }
        public static void Main(String[] args)
        {
            string input = "GeeksforGeeks!@12";
            printStrongNess(input);
        }
    }
}
