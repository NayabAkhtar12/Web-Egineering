﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
class Solution
{

    static void Main(String[] args)
    {
        int q = Convert.ToInt32(Console.ReadLine());
        string hack = "hackerrank";
        for (int a0 = 0; a0 < q; a0++)
        {
            string s = Console.ReadLine();
            int length = s.Length;
            int h = 0;
            // your code goes here

            for (int i = 0; i < length; i++)
            {
                if (s[i] == hack[h])
                {
                    h++;
                }
                if (h == 10)
                    break;
            }
            Console.WriteLine(h == 10 ? "YES" : "NO");
        }
    }
}