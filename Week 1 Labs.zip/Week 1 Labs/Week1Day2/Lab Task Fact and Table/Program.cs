﻿using System;

namespace StringManipulation
{
    class Program
    {
        //Functions
        private static void Factorial(int number)
        {
            int i, fact = 1;
            for (i = 1; i <= number; i++)
            {
                fact = fact * i;
            }
            Console.Write("Factorial of " + number + " is: " + fact);
        }

        private static void table(int n)
        {
            Console.Write("Display the multiplication table:\n");
            Console.Write("-----------------------------------");
            for (int j = 1; j <= 10; j++)
            {
                Console.WriteLine("{0} X {1} = {2} \n", n, j, n * j);
            }
        }


        static void Main(string[] args)
        {
            int number;
            Console.WriteLine("Enter any Number: ");
            number = int.Parse(Console.ReadLine());
            bool showMenu = true;
            while (showMenu)
            {
                showMenu = MainMenu();
            }
        }
        private static bool MainMenu()
        {
            int number;
            Console.WriteLine("Enter any Number: ");
            number = int.Parse(Console.ReadLine());
            Console.Clear();
            Console.WriteLine("Choose an option:");
            Console.WriteLine("1) Factorial");
            Console.WriteLine("2) Table");
            Console.WriteLine("3) Exit");
            Console.Write("\r\nSelect an option: ");

            switch (Console.ReadLine())
            {
                case "1":
                    Factorial(number);
                    return true;
                case "2":
                    table(number);
                    return true;
                case "3":
                    return false;
                default:
                    return true;
            }
        }

        

    }
}