﻿using System;
using System.Collections.Generic;
using System.IO;

class Solution
{
    static void Main(String[] args)
    {
        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution */
        var n = int.Parse(Console.ReadLine());

        for (var i = 0; i < n; i++)
        {
            for (var j = 0; j < n - 1 - i; j++)
            {
                Console.Write(" ");
            }

            for (var j = 0; j < i + 1; j++)
            {
                Console.Write("#");
            }

            Console.WriteLine();
        }
    }
}