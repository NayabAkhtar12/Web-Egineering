﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
class Solution
{

    static void Main(String[] args)
    {
        int q = Convert.ToInt32(Console.ReadLine());
        string h = "hackerrank";
        for (int a0 = 0; a0 < q; a0++)
        {
            string s = Console.ReadLine();
            // your code goes here
            int k = 0;
            for (int i = 0; i < s.Length; i++)
            {
                if (k == 10)
                {
                    break;
                }
                if (s[i] == h[k]) k++;
            }
            if (k == 10) Console.WriteLine("YES");
            else Console.WriteLine("NO");
        }
    }
}