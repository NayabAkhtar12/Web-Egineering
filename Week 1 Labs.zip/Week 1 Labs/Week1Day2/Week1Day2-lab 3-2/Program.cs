﻿class Animal
{
    public void walk()
    {
        Console.WriteLine("I am walking");
    }
}

class Bird :  Animal
{
    public void fly()
   {
        Console.WriteLine("I am flying");
    }
     public void sing(){
        Console.WriteLine("I am singing");
    }
}
public class Solution
{

    static void Main(string[] args)
    {

        Bird bird = new Bird();
        bird.walk();
        bird.fly();
        bird.sing();
    }
}