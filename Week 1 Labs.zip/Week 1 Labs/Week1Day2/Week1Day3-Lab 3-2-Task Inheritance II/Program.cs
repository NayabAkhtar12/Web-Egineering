﻿class Arithmatic { };
class Adder : Arithmatic
{
    public int add(int a, int b)
{
    return a + b;

}
}
public class Solution
{

    static void Main(string[] args)
    {

        Adder A1 = new Adder();
        Console.WriteLine("sum is", A1.add(1, 2));

    }
}